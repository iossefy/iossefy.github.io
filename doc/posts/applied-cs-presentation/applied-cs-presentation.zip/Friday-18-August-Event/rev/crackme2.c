#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define LICENSE_KEY "SECRET_KEY-"

/* Generate random number in range min and max */
int get_random_number(int min, int max) {
	time_t seed;
	srand((unsigned)time(&seed));
	return rand() % (max + 1 - min) + min;
}

/* verifies if the key is correct */
int verify_key(char *key)
{
	char buffer[10 + 5];
	int random = get_random_number(1000, 9999);

	snprintf(buffer, 10 + 5, "%s%d", LICENSE_KEY, random);

	if (strcmp(key, buffer) == 0) {
		return 1;
	}
	
	return 0;
}

int main(int argc, char **argv)
{
	if (argc < 2) {
		printf("Usage: ./%s <license key>\n", argv[0]);
		return 1;
	}

	if (!verify_key(argv[1])) {
		printf("ACCESS DENIED. TRY AGAIN\n");
		return 0;
	}

	printf("\n\nACCESS GRANTED!!!");
	printf("YOU WON!!! YOU CRACKED THE CODE!\n\n");

	return 0;
}
