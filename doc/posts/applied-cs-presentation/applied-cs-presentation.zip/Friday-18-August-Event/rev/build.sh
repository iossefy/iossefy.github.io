#!/bin/sh
gcc crackme1.c -g3 -o crackme1
gcc crackme2.c -g3 -o crackme2

