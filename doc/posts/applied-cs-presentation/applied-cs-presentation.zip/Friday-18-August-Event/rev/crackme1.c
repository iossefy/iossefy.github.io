#include <stdio.h>
#include <string.h>

int verify_key(char *key)
{
	if (strcmp(key, "SECRET_KEY1337") == 0) {
		return 1;

	}
	return 0;
}

int main(int argc, char **argv)
{
	if (argc < 2) {
		printf("Usage: %s <license key>\n", argv[0]);
		return 1;
	}

	if (!verify_key(argv[1])) {
		printf("ACCESS DENIED. TRY AGAIN\n");
		return 0;
	}

	printf("ACCESS GRANTED!!!\n");

	return 0;
}


