Simple crackme challenge

-- build the source code

$ ./build.sh


LICENSE: public domain
