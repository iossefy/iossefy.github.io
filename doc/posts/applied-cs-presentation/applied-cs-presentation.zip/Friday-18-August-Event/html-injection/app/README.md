# Vulnerable HTML Injection app

### requirements
- python3
- pip

### install
```
pip install flask
```

### run
```
python app.py
```

### LICENSE
Public domain
