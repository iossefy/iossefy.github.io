#!/usr/bin/env python
from flask import Flask, render_template, request, make_response
from markupsafe import escape
from hashlib import sha256

app = Flask(__name__)

creds = {'admin': 'password1'}

def generate_sessionid(user):
    return sha256(user.encode('utf-8')).hexdigest()

@app.route('/login', methods=['POST', 'GET'])
def login():

    if request.method == 'GET':
        return render_template('login.html')

    if request.method == 'POST':

        # get username and password from input
        username = request.form['username']
        password = request.form['password']

        # if username and password are correct
        if creds.get(username) == password:
            resp = make_response(render_template('hello.html', name=username))
            resp.set_cookie('user_id', generate_sessionid(username))

            return resp
        else:
            return render_template('login.html', message="<p style='color:#FF0000'> Username and/or password is incorrect </p>")



@app.route('/signup', methods=['POST', 'GET'])
def signup():

    if request.method == 'GET':
        return render_template('signup.html')

    if request.method == 'POST':

        # get username and password from input
        username = request.form['username']
        password = request.form['password']

        # store username and password into database
        if username in creds: # if user is already registered
            return render_template('signup.html',
                                   message="<p style='color:#FF0000'>this username is used. try another one</p>")


        creds[username] = password
        print(creds)


        return render_template('login.html',
                               message="<p style='color:#0000FF'>username registered successfuly!</p>")


@app.route("/profiles/<username>")
def hello(username):
    return render_template('hello.html', name=username)

@app.route("/")
def index():

    profiles = [pf for pf in creds.keys()]
    print(profiles)
    return render_template('index.html', profiles=profiles)



if __name__ == '__main__':
    app.jinja_options["autoescape"] = lambda _: False
    app.run(debug=True)
